exec((__import__('pathlib').Path(__file__).resolve().parent/'browser_smoke.py').read_text().split('with sync_playwright() as p:')[0].replace('Path(__file__).resolve().parents[1]','Path(__file__).resolve().parents[1]'))
from playwright.sync_api import sync_playwright
from datetime import date
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 for name in ['index.html','commissions.html','fleet.html']:
  pg=b.new_page();errs=run(pg,name,{'gp_session_user':seed})
  if name=='index.html':
   res=pg.evaluate('''async () => {
     captureGeotag = async () => ({address:'Test site',coords:''});
     document.getElementById('manDate').value=GP.localDate();
     document.getElementById('manStart').value='08:00';document.getElementById('manEnd').value='17:00';
     await submitManualTime();return JSON.parse(localStorage.getItem('gp_time_logs')||'[]');
   }''')
   assert len(res)==1 and res[0]['decimal_hours']=='08.50'; print('Manual shift saved offline',res[0]['decimal_hours'])
  if name=='commissions.html':
   res=pg.evaluate('''async () => {
     document.getElementById('commWoNumber').value='WO-555';document.getElementById('commDate').value=GP.localDate();
     document.getElementById('commAmount').value='250';await submitCommissionLog();
     return JSON.parse(localStorage.getItem('gp_commission_logs')||'[]');
   }''')
   assert len(res)==1 and res[0]['wo_number']=='WO-555';print('Commission saved offline',res[0]['wo_number'])
  if name=='fleet.html':
   res=pg.evaluate('''async () => {
     markAllPassing();document.getElementById('garageVehicleSelect').value='1';onSelectGarageVehicle();
     document.getElementById('vMileage').value='50005'; await submitVehicleInspection();
     return JSON.parse(localStorage.getItem('gp_vehicle_logs')||'[]');
   }''')
   assert len(res)==1 and res[0]['mileage']=='50005';print('Inspection saved offline',res[0]['mileage'])
  assert not errs,errs
  pg.close()
 b.close()
