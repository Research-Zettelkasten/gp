# GLASSPRO Portal Code Review

**Reviewed:** 2026-10-30  
**Input:** `glasspro-portal-updated.zip` (5 standalone HTML pages plus `VERSION.JSON`)  
**Result:** `glasspro-portal-repaired.zip` (the original functionality with targeted repairs and added tests)

## Executive summary

The portal is a multi-page frontend with inline scripts, browser-stored sessions and data, and direct Supabase calls. The core screens rendered successfully in a simulated browser after the changes listed below. However, the architecture is **not suitable for confidential employee, payroll, GPS and customer records on a public site** without a server-backed authentication/authorization redesign.

## Findings and changes

| Severity | Finding | Change / status |
|---|---|---|
| CRITICAL | Demo PINs, roles and sessions stored in JavaScript/localStorage; console/localStorage can forge admin access | **NOT FIXED ARCHITECTURALLY**. Added/retained UX permission checks and removed some UI PIN disclosures. Requires actual Auth + server-side policies. |
| CRITICAL | Client/server trust boundary unknown: Supabase publishable key used from frontend for CRUD, no RLS schema provided | **NOT VERIFIED**. Must inspect and enforce RLS for all 7 tables; audit storage and public access. |
| CRITICAL | Customer quote details embedded in the HTML fixture, readable to anyone with the page source | **NOT REMOVED to preserve supplied data**. Migrate those records to an authenticated backend before deploying. |
| HIGH | Cloud insert errors can still result in a “saved” message, or local items disappear on refresh | Fixed for new manual/time, commission and fleet records: preserve local data, merge with cloud on read, and report local-only status. Complete automatic retry/reconciliation remains open. |
| HIGH | Display templates interpolate strings from local data, CSV and Supabase into `innerHTML` | Escaped representative untrusted fields across primary tables and print views, corrected unsafe dynamic name handlers; injection regressions pass. Additional templates warrant a full security audit. |
| HIGH | Overtime and paycheck calculations sum all historical shifts instead of the current week | Changed time-clock overtime and pay calculation and admin weekly watchlist/payroll/employee modal to Monday–Sunday local work week; historical dashboard totals remain all-time. |
| MEDIUM | Admin CSV exports have no consistent quoting and can contain spreadsheet formulas | Central CSV escaper + formula neutralization, Unicode BOM and revoke blob URLs. |
| MEDIUM | Form logic accepts missing dates, invalid/non-numeric mileage, duplicate work orders | Added validation to key submit workflows. |
| MEDIUM | Timestamp work dates use UTC conversions, which can shift the local day | Uses `GP.localDate()`, and clock-out shifts use clock-in date. Overnight shift accounting still needs business-rule review. |
| MEDIUM | Hardcoded quote follow-up date and CSR PINs in stamps | Rolling follow-up date, removed PINs from new stamps and status. Historical stamps may already include PIN strings. |
| LOW | Geocoder appends 'GA' regardless of GPS coordinates; Supabase indicator claims connection when merely initialized | Removed state assumption; indicator now labels configuration unverified. |

## Verified tests (offline / simulated browser)

- JavaScript syntax: **5/5 HTML pages passed** Node syntax extraction/check.
- Basic page render: **5/5 pages** rendered without uncaught errors with mocked external scripts and mock localStorage.
- Injection and behavior smoke checks: **7 passed** (5 render/injection cases, quote admin-tab UX guard, weekly-hours filter).
- Local form persistence: **3 passed** (manual shift, commission, fleet inspection).
- Helpers: **6 passed** (HTML escaping, CSV formula/quote handling, week/date logic).

Tests do **not** verify live Supabase connections, production RLS, browser navigation over HTTP, network error timing, or actual payroll/quote accounting correctness. Some online libraries and backend services were unavailable for live integration checks.

## Priority next steps

1. Build a secure server-backed authentication/authorization model and audit every table's RLS before public deployment.
2. Remove hardcoded personal data and PIN-based fixtures from public assets; move fixtures to private migration/test setup.
3. Design durable sync (idempotent IDs, queued retries, server-generated IDs, conflict resolution and true cloud status). Without this, local-only data can diverge between browsers.
4. Add integration tests against a disposable Supabase instance and role-specific negative access tests.
5. Agree on payroll week boundaries, overnight shifts, rate/tax handling and approval/audit trail rules, then enforce them on the server. Current pay output is an estimate, not payroll advice.
6. Audit remaining HTML interpolation and third-party CDN dependencies, adopt CSP and modular source/build tooling.

**Deployment decision: do not approve for a public production site containing real employee or customer data yet.**
