from pathlib import Path
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
import re,subprocess,sys
from datetime import date, timedelta
TODAY=date.today().isoformat()
OLD=(date.today()-timedelta(days=8)).isoformat()
D=Path(__file__).resolve().parents[1]
seed={'employee_name':'Test User','department':'Operations','employment_type':'Full-Time','pin_code':'9999','perm_time':True,'perm_commission':True,'perm_vehicle_submit':True,'perm_vehicle_view':True,'perm_admin':True,'perm_safety':True}
xss='<img src=x onerror="window.xss=(window.xss||0)+1">'
utils=(D/'portal-utils.js').read_text()
bootstrap='''const db=new Map();for(let [k,v] of Object.entries(window.__init || {}))db.set(k,JSON.stringify(v));const storage={getItem:k=>db.has(k)?db.get(k):null,setItem:(k,v)=>db.set(k,String(v)),removeItem:k=>db.delete(k),clear:()=>db.clear()};Object.defineProperty(window,'localStorage',{configurable:true,value:storage});Object.defineProperty(window,'sessionStorage',{configurable:true,value:storage});window.supabase=undefined;window.lucide={createIcons(){}};window.tailwind={config:{}};window.Papa={parse(){}};'''
def html(name):
 soup=BeautifulSoup((D/name).read_text(),'html.parser')
 for s in soup.find_all('script',src=True):
  if s['src']=='portal-utils.js':s.replace_with(BeautifulSoup('<script>'+utils+'</script>','html.parser'))
  else:s.decompose()
 for l in soup.find_all('link',href=True):
  if l['href'].startswith('https:'):l.decompose()
 return str(soup)
def run(pg,name,init):
 pg.evaluate('obj=>window.__init=obj',init);pg.evaluate('js=>eval(js)',bootstrap)
 errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
 pg.set_content(html(name),wait_until='domcontentloaded',timeout=9000)
 pg.wait_for_timeout(170)
 return errs
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox']);pass_count=0
 cases=[
 ('index.html',{'gp_time_logs':[{'employee_name':'Test User','work_date':TODAY,'decimal_hours':'8','clock_in_location':xss},{'employee_name':'Test User','work_date':OLD,'decimal_hours':'90'}]}),
 ('commissions.html',{'gp_commission_logs':[{'employee_name':'Test User','work_date':TODAY,'wo_number':xss,'job_type':'a','job_amount':1,'status':'Pending','spec_notes':xss}]}),
 ('fleet.html',{'gp_vehicle_logs':[{'employee_name':xss,'inspection_date':TODAY,'license_plate':'z','make':'X','model':xss,'mileage':'5','issues_count':1,'discrepancies':xss,'additional_comments':xss}]}),
 ('quotes.html',{'glasspro_quotes_v1':[{'quote_number':51,'quote_date':TODAY,'module':'Auto','customer_name':xss,'phone':xss,'csr':'SC: CALHOUN, STEPHANIE','parts':[{'desc':xss,'part':xss}],'total':100,'tax':0,'status':'follow_up','call_data':{'notes':xss,'still_for_review':'yes','expected_answer_date':TODAY,'csr_stamp':xss}}],'glasspro_competitors_v1':[{'id':1,'name':xss,'specialty':xss,'active':True}]}),
 ('admin.html',{'gp_app_users':[{'id':22,'employee_name':xss,'department':'Operations','employment_type':'Full-Time','pin_code':'3333','perm_time':True}], 'gp_audit_logs':[{'timestamp':TODAY,'action_type':'ALERT','supervisor_name':xss,'details':xss}],'gp_time_logs':[{'id':1,'employee_name':xss,'work_date':TODAY,'clock_in':'09:00','clock_out':'10:00','decimal_hours':'1','notes':xss,'clock_in_location':xss}], 'gp_commission_logs':[{'id':1,'employee_name':xss,'work_date':TODAY,'wo_number':xss,'job_type':'X','spec_notes':xss,'status':'Pending'}]})
 ]
 for name,extras in cases:
  pg=b.new_page(); errors=run(pg,name,{'gp_session_user':seed,**extras}); x=pg.evaluate('window.xss||0');print(name,'errors',errors[:2],'XSS events',x)
  if x or errors:print('FAILED',name);sys.exit(1)
  pass_count+=1;pg.close()
 # test nonadmin clients cannot see admin UI
 pg=b.new_page(); nonadmin={**seed,'perm_admin':False};run(pg,'quotes.html',{'gp_session_user':nonadmin});pg.evaluate('switchTab("admin-review")'); assert 'hidden' in pg.locator('#tab-panel-admin-review').get_attribute('class'); print('non-admin quotes access guarded');pass_count+=1;pg.close()
 pg=b.new_page();run(pg,'index.html',{'gp_session_user':seed,'gp_time_logs':[{'employee_name':'Test User','work_date':TODAY,'decimal_hours':'8'},{'employee_name':'Test User','work_date':OLD,'decimal_hours':'100'}]}); assert '08.00' in pg.locator('#empOvertimeText').inner_text(); print('weekly window correct');pass_count+=1;pg.close()
 b.close()
 print('PASS',pass_count,'browser security and behavior cases')
