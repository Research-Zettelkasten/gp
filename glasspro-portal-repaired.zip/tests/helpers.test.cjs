/* Run: node tests/helpers.test.cjs */
const fs = require('fs'), vm = require('vm'), path = require('path'), assert = require('assert');
const ctx = {}; vm.createContext(ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'..','portal-utils.js'),'utf8'),ctx);
const g = ctx.GP;
assert.strictEqual(g.escapeHtml('<script>"&'), '&lt;script&gt;&quot;&amp;');
assert.strictEqual(g.csvCell('=HYPERLINK("evil")'), '"\'=HYPERLINK(""evil"")"');
assert.strictEqual(g.csvCell('a"b'), '"a""b"');
assert(g.isInCurrentWeek('2026-10-30', new Date(2026,9,30)));
assert(!g.isInCurrentWeek('2026-10-25', new Date(2026,9,30)));
assert.strictEqual(g.localDate(new Date(2026,9,30)), '2026-10-30');
console.log('PASS: six helper checks');
